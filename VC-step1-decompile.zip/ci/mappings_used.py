#!/usr/bin/env python3
"""List every Minecraft name the mods use (class_123 / method_456 / field_789)
together with its Yarn and Mojang name, read from the tiny-v2 mapping files
that Fabric Loom downloaded. Output is one small TSV file."""
import argparse
import io
import re
import struct
import sys
import zipfile

NAME_RE = re.compile(r'(?<![A-Za-z0-9_])(?:class|method|field)_\d+')


def utf8_constants(data):
    """Return every Utf8 string in a .class file's constant pool."""
    if data[:4] != b'\xca\xfe\xba\xbe':
        return []
    (count,) = struct.unpack('>H', data[8:10])
    pos, idx, out = 10, 1, []
    while idx < count:
        tag = data[pos]
        if tag == 1:
            (length,) = struct.unpack('>H', data[pos + 1:pos + 3])
            out.append(data[pos + 3:pos + 3 + length].decode('utf-8', 'replace'))
            pos += 3 + length
        elif tag in (3, 4, 9, 10, 11, 12, 17, 18):
            pos += 5
        elif tag in (5, 6):
            pos += 9
            idx += 1  # long/double use two slots
        elif tag in (7, 8, 16, 19, 20):
            pos += 3
        elif tag == 15:
            pos += 4
        else:
            raise ValueError('unknown constant pool tag %d' % tag)
        idx += 1
    return out


def collect_names(jars):
    """{name: set(of mod classes that mention it)}"""
    found = {}
    for jar in jars:
        with zipfile.ZipFile(jar) as z:
            for info in z.infolist():
                if not info.filename.endswith('.class'):
                    continue
                short = info.filename[:-6].split('/')[-1]
                for text in utf8_constants(z.read(info.filename)):
                    for name in NAME_RE.findall(text):
                        found.setdefault(name, set()).add(short)
    return found


def parse_tiny(stream):
    """Parse a tiny-v2 file with 'intermediary' and 'named' columns.
    Returns (classes, members) or None if the file is not usable."""
    header = stream.readline().rstrip('\n').split('\t')
    if len(header) < 5 or header[0] != 'tiny' or header[1] != '2':
        return None
    ns = header[3:]
    if 'intermediary' not in ns or 'named' not in ns:
        return None
    ii, ni = ns.index('intermediary'), ns.index('named')
    classes, members = {}, {}
    cur = ''
    for line in stream:
        line = line.rstrip('\n')
        if not line:
            continue
        if line[0] == 'c':
            parts = line.split('\t')
            parts += [''] * (1 + len(ns) - len(parts))
            inter, named = parts[1 + ii], parts[1 + ni]
            token = inter.split('/')[-1].split('$')[-1]
            cur = named or inter
            if token:
                classes[token] = cur
        elif line[0] == '\t' and line[1:2] in ('f', 'm'):
            parts = line[1:].split('\t')  # kind, desc, names...
            parts += [''] * (2 + len(ns) - len(parts))
            inter, named = parts[2 + ii], parts[2 + ni]
            if inter:
                members[inter] = (named or inter, cur)
    return classes, members


def open_tiny(path):
    if path.endswith('.jar'):
        z = zipfile.ZipFile(path)
        for candidate in ('mappings/mappings.tiny', 'mappings.tiny'):
            if candidate in z.namelist():
                return io.TextIOWrapper(z.open(candidate), encoding='utf-8', errors='replace')
        return None
    return open(path, encoding='utf-8', errors='replace')


def flavour(classes):
    """Tell Yarn from Mojang names with a well-known probe class."""
    probe = classes.get('class_1657', '')  # the player class
    if probe.endswith('/PlayerEntity'):
        return 'yarn'
    if probe.endswith('/Player'):
        return 'mojmap'
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--jars', nargs='+', required=True)
    ap.add_argument('--tiny', nargs='+', required=True)
    args = ap.parse_args()

    maps = {}
    for path in args.tiny:
        try:
            stream = open_tiny(path)
            if stream is None:
                continue
            with stream:
                parsed = parse_tiny(stream)
        except Exception as exc:  # keep going, other files may work
            print('   skip %s (%s)' % (path, exc))
            continue
        if not parsed:
            continue
        kind = flavour(parsed[0])
        print('   %s -> %s' % (path, kind or 'unknown'))
        if kind and kind not in maps:
            maps[kind] = parsed

    names = collect_names(args.jars)
    print('   %d distinct Minecraft names used by the mods' % len(names))

    def lookup(kind, name):
        if kind not in maps:
            return ('', '')
        classes, members = maps[kind]
        if name.startswith('class_'):
            return (classes.get(name, ''), '')
        hit = members.get(name)
        return hit if hit else ('', '')

    def sort_key(n):
        return (n.split('_')[0], int(n.split('_')[1]))

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('kind\tintermediary\tyarn\tmojmap\tyarn_owner\tmojmap_owner\tused_by\n')
        for name in sorted(names, key=sort_key):
            y, yo = lookup('yarn', name)
            m, mo = lookup('mojmap', name)
            users = ','.join(sorted(names[name])[:3])
            f.write('\t'.join([name.split('_')[0], name, y, m, yo, mo, users]) + '\n')
    print('   wrote %s (yarn: %s, mojmap: %s)' % (args.out, 'yarn' in maps, 'mojmap' in maps))


if __name__ == '__main__':
    sys.exit(main())
