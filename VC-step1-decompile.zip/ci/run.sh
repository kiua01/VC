#!/usr/bin/env bash
# =====================================================================
# VC step 1 - decompile Viltrumite Core + Flight (Fabric 1.20.1)
# Runs inside GitHub Actions. It never stops at the first error, so the
# output folder always holds whatever worked, plus the logs.
# =====================================================================
set -u

JAVA_VERSION=21
GRADLE_VERSION=8.12.1
VINEFLOWER_VERSION=1.10.1

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/out"
TOOLS="$ROOT/tools"
mkdir -p "$OUT/decompiled" "$OUT/logs" "$TOOLS"
exec > >(tee -a "$OUT/logs/run.log") 2>&1

# --- Java (the workflow installs 21 and 25 side by side) -------------
JH_VAR="JAVA_HOME_${JAVA_VERSION}_X64"
if [ -n "${!JH_VAR:-}" ]; then
  export JAVA_HOME="${!JH_VAR}"
  export PATH="$JAVA_HOME/bin:$PATH"
fi
echo "=== Java ==="
java -version 2>&1 | head -1

# --- Tools ------------------------------------------------------------
echo "=== Download Vineflower $VINEFLOWER_VERSION ==="
if ! curl -fsSL --retry 3 -o "$TOOLS/vineflower.jar" \
  "https://repo1.maven.org/maven2/org/vineflower/vineflower/${VINEFLOWER_VERSION}/vineflower-${VINEFLOWER_VERSION}.jar"; then
  echo "!! Could not download Vineflower - nothing to do"
  exit 1
fi

echo "=== Download Gradle $GRADLE_VERSION ==="
HAVE_GRADLE=0
if curl -fsSL --retry 3 -o "$TOOLS/gradle.zip" \
  "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" \
  && unzip -q "$TOOLS/gradle.zip" -d "$TOOLS"; then
  export PATH="$TOOLS/gradle-${GRADLE_VERSION}/bin:$PATH"
  HAVE_GRADLE=1
else
  echo "!! Gradle download failed - the readable-names decompile will be skipped"
fi

# decompile <label> <part> <jar> [library jars...]
decompile() {
  local label="$1" part="$2" jar="$3"
  shift 3
  local dest="$OUT/decompiled/$label/$part"
  local libs=()
  local l
  for l in "$@"; do libs+=("-e=$l"); done
  mkdir -p "$dest"
  echo "--- decompiling [$label/$part] $(basename "$jar")"
  java -Xmx3g -jar "$TOOLS/vineflower.jar" -dgs=1 -asc=1 -rsy=1 -mpm=60 \
    "${libs[@]}" "$jar" "$dest" > "$OUT/logs/vineflower-$label-$part.log" 2>&1
  find "$dest" -type f ! -name '*.java' -delete
  echo "    -> $(find "$dest" -name '*.java' | wc -l) .java files"
}

part_of() {
  case "$1" in
    *core*)   echo core ;;
    *flight*) echo flight ;;
    *)        basename "$1" .jar ;;
  esac
}

# --- A) raw decompile: always works, Minecraft names stay class_1234 --
echo "=== A) raw decompile (intermediary names) ==="
for jar in "$ROOT"/jars/*.jar; do
  decompile intermediary "$(part_of "$(basename "$jar")")" "$jar"
done

# --- B) readable names via Fabric Loom --------------------------------
if [ "$HAVE_GRADLE" = 1 ]; then
  for m in yarn mojmap; do
    echo "=== B) remap + decompile with $m names ==="
    rm -f "$ROOT/remap/build/classpath.txt"
    if gradle --no-daemon --console=plain -p "$ROOT/remap" "-PvcMappings=$m" printRemapped \
        > "$OUT/logs/gradle-$m.log" 2>&1; then
      tail -n 3 "$OUT/logs/gradle-$m.log"
      mapfile -t CP < "$ROOT/remap/build/classpath.txt"
      REMAPPED=()
      LIBS=()
      for p in "${CP[@]}"; do
        case "${p,,}" in
          *viltrumite*.jar) REMAPPED+=("$p") ;;
          *.jar)            LIBS+=("$p") ;;
        esac
      done
      echo "    remapped mod jars found: ${#REMAPPED[@]}, library jars: ${#LIBS[@]}"
      for jar in "${REMAPPED[@]}"; do
        decompile "$m" "$(part_of "$(basename "$jar")")" "$jar" "${LIBS[@]}"
      done
    else
      echo "!! Gradle/Loom failed for $m - last lines of its log:"
      tail -n 40 "$OUT/logs/gradle-$m.log"
    fi
  done
fi

# --- C) table of every Minecraft name the mods use --------------------
echo "=== C) name table (intermediary -> Yarn -> Mojang) ==="
mapfile -t TINY < <(find "$HOME/.gradle" "$ROOT/remap/.gradle" \
  \( -name '*.tiny' -size +200k -o -name 'yarn-1.20.1*-v2.jar' \) 2>/dev/null)
echo "    mapping files found: ${#TINY[@]}"
if [ "${#TINY[@]}" -gt 0 ]; then
  python3 "$ROOT/ci/mappings_used.py" --out "$OUT/mappings-used.tsv" \
    --jars "$ROOT"/jars/*.jar --tiny "${TINY[@]}" || echo "!! name table failed"
fi

# --- Summary ------------------------------------------------------------
echo "=== SUMMARY ==="
for d in "$OUT"/decompiled/*/*; do
  [ -d "$d" ] && echo "$(basename "$(dirname "$d")")/$(basename "$d"): $(find "$d" -name '*.java' | wc -l) java files"
done
[ -f "$OUT/mappings-used.tsv" ] && echo "mappings-used.tsv: $(wc -l < "$OUT/mappings-used.tsv") rows"
echo "done"
exit 0
